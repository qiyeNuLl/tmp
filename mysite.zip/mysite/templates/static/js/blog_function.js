/**返回顶部功能**/
var go_top = document.querySelector('.go_top');
window.onscroll = function(){
	var t = document.documentElement.scrollTop || document.body.scrollTop;
	
	if ( t >= 100 ){
		go_top.style.display = 'block';
	}else{
		go_top.style.display = 'none';
	}
}


function go_back(){
	var nums = new Array();
	nums = [182, 325, 611, 469, 754, 897, 40];
	var i = 0;
	var go_top = 0;
	var timer = setInterval(function(){
		go_top = -nums[i];
		document.getElementById('go_top').style.backgroundPositionX = go_top + "px";
		i++;
		if ( i > 7 ){
			clearInterval(timer);
			document.getElementById('go_top').className = "go_top fly";
			var to = document.documentElement.scrollTop || document.body.scrollTop;
			
			var goer = setInterval(function(){
				to -= 100;
				if ( to <= 0 ){
					clearInterval(goer);
				}
				document.documentElement.scrollTop = document.body.scrollTop = to;
				document.getElementById('go_top').className = "go_top";
			}, 20)
		}
	}, 100)
}