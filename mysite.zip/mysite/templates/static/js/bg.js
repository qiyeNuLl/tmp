bgs = new Array(2);
bgs[0] = 'img/1.jpg';
bgs[1] = 'img/2.jpg';
index = Math.floor(Math.random()*bgs.length);
document.write(""+"")