from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse
from . import models
from django import forms
from .forms import UserForm
from .forms import Search
from .models import BlogArticles
from .models import SearchText
import hashlib
#这个文件，函数路由

#敏感信息加密
def hash_code(s, salt='mysite_login'):# 加点盐
    h = hashlib.sha256()
    s += salt
    h.update(s.encode()) # update方法只接收bytes类型
    return h.hexdigest()

#注册页面表单类
class RegisterForm(forms.Form):
    gender = (
    ('male', "男"),
    ('female', "女"),
        )
    username = forms.CharField(label="用户名", max_length=128, widget=forms.TextInput(attrs={'class': 'login_box'}))
    password1 = forms.CharField(label="密码", max_length=256, widget=forms.PasswordInput(attrs={'class': 'login_box'}))
    password2 = forms.CharField(label="确认密码", max_length=256, widget=forms.PasswordInput(attrs={'class': 'login_box'}))
    email = forms.EmailField(label="邮箱地址", widget=forms.EmailInput(attrs={'class': 'login_box'}))
    sex = forms.ChoiceField(label='性别', choices=gender)


#def index(request):
    #return HttpResponse("Hello, world. You're at the polls index.")
# Create your views here.
#主页
def index(request):
    pass
    return render(request, 'base.html')

#登录页
def login(request):
    if request.session.get('is_login',None):
        return redirect('/index')
    if request.method == "POST":
        login_form = UserForm(request.POST)
        message = "所有字段都必须填写！"
        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            try:
                user = models.User.objects.get(name=username)
                if user.password == hash_code(password):
                    request.session['is_login'] = True
                    request.session['user_id'] = user.id
                    request.session['user_name'] = user.name
                    return redirect('/index/')
                else:
                    message = "密码不正确！"
            except:
                message = "用户名不存在！"
        return render(request, 'login.html', locals())

    login_form = UserForm()
    return render(request, 'login.html', locals())

#注册页  
def register(request):
    if request.session.get('is_login', None):
        return redirect("/index/")
    if request.method == 'POST':
        register_form = RegisterForm(request.POST)
        message = "请检查填写的内容！"
        if register_form.is_valid():
            username = register_form.cleaned_data['username']
            password1 = register_form.cleaned_data['password1']
            password2 = register_form.cleaned_data['password2']
            email = register_form.cleaned_data['email']
            sex = register_form.cleaned_data['sex']
            if password1 != password2:
                message = "两次输入的密码不同！"
                return render(request, 'register.html', locals())
            else:
                same_name_user = models.User.objects.filter(name=username)
                if same_name_user:
                    message = '用户已经存在，请重新选择用户名！'
                    return render(request, 'register.html', locals())
                same_email_user = models.User.objects.filter(email=email)
                if same_email_user:
                    message = '该邮箱地址已被注册，请使用别的邮箱！'
                    return render(request, 'register.html', locals())
                    
                new_user = models.User.objects.create()
                new_user.name = username
                new_user.password = hash_code(password1)
                new_user.email = email
                new_user.sex = sex
                new_user.save()
                return redirect('/login/')
    register_form = RegisterForm()
    return render(request,'register.html', locals())

#注销 
def logout(request):
    if not request.session.get('is_login', None):
  # 如果本来就未登录，也就没有登出一说
        return redirect("/index/")
    request.session.flush()
    return redirect('/index/')
    

def blog_title(request):
    blogs = BlogArticles.objects.all()
    return render(request, "blog/title.html", {"blogs": blogs})
	
	
def blog_search(request):
	search_key = request.POST.get('serach_key');
	error_msg = ''
	
	blogs = BlogArticles.objects.filter(title__icontains = search_key)
	return render(request, "blog/search.html", {"blogs": blogs})
	
	
def blog_article(request, article_id):
    #article = BlogArticles.objects.get(id=article_id)
    article = get_object_or_404(BlogArticles, id = article_id)
    pub = article.publish
    return render(request, "blog/content.html", {"article":article, "publish":pub})
	