from django.urls import path
from . import views

urlpatterns = [
    #path('', views.index, name='index'),
	path('search', views.blog_search, name = "blog_search"),
    path('', views.blog_title),
    path('<article_id>', views.blog_article, name = "blog_article"),
	#path('serach/<article_id>/', views.blog_article, name = "blog_article"),
]