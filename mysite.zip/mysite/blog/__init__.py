import pymysql
from django import forms
pymysql.install_as_MySQLdb()