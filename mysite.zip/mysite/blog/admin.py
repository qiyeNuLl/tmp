from django.contrib import admin
from . import models
admin.site.register(models.User)
from .models import BlogArticles
admin.site.register(BlogArticles)

# Register your models here.
