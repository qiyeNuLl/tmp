from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

# Create your models here.
class User(models.Model):
    '''用户表'''

    gender = (
    ('male','男'),
    ('female','女'),
    )

    name = models.CharField(max_length=128,unique=True)
    password = models.CharField(max_length=256)
    email = models.EmailField(unique=True)
    sex = models.CharField(max_length=32,choices=gender,default='男')
    c_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['c_time']
        verbose_name = '用户'
        verbose_name_plural = '用户'

  
class BlogArticles(models.Model):
    title = models.CharField(max_length=300)
    author = models.ForeignKey(User, related_name='blog_posts', on_delete=models.CASCADE)#必须要有on_delete=models.CASCADE，不然报错
    body = models.TextField()
    publish = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ("-publish",)

    def __str__(self):
        return self.title

class SearchText(models.Model):
	search_key = models.CharField(max_length=10)
	
	class Meta:
	    ordering = ['search_key']
	
	def __str__(self):
	    return self.search_key
	
	
